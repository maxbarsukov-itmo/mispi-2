// var. 1571
public class Lab4 {
  public static void main(String[] args) {
  E a = new E();
  E b = new C();
  C c = new C();
  c.x31();
  b.x17();
  c.x37();
  a.x9();
  a.x10();
  c.x20();
  b.x19();
  b.x34();
  c.x28();
  c.x35();
  b.x25(a);
  a.x25(b);
  c.x25(c);
  }
}
previous : 8
