class C extends E {
  public C() {
    x22 = 4;
    x24 = 8;
    x16 = 8;
    x30 = 9;
    x29 = 4L;
  }
  public void x31() {
    System.out.println("метод x31 в классе C");
    System.out.println(x22 - 4);
  }
  public void x17() {
    System.out.println("метод x17 в классе C");
    System.out.println(x1[1]);
  }
  public void x37() {
    System.out.println("метод x37 в классе C");
    System.out.println(x16 - 1);
  }
  public static void x19() {
    System.out.println("метод x19 в классе C");
    System.out.println((x14 - 2));
  }
  public static void x34() {
    System.out.println("метод x34 в классе C");
    System.out.println(--x14);
  }
  public static void x28() {
    System.out.println("метод x28 в классе C");
    System.out.println(x23);
  }
  public static void x35() {
    System.out.println("метод x35 в классе C");
    System.out.println((x23 + 4));
  }
  public void x25(E r) {
    r.x37();
  }
  public void x25(C r) {
    r.x9();
  }
}
